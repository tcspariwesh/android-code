package org.geeksforgeeks.demo

class Contacts (
    // name of the contact
    var userName: String,
    // contact number
    var contactNumber: String
)